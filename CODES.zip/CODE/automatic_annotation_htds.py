
from ultralytics import YOLO
import cv2
import numpy as np
import supervision as sv
import os


def create_folder(folder_path):
    os.makedirs(folder_path, exist_ok=True)

def main():
    
    results = []  # List to store the inference results

    folder_path = r'D:\Downloads\OPEN\htds_night_2\htds_Night_task_10'
    
    #Load the YOLOv8 Model
    model=YOLO('best_d_scratch.pt')
    i = 0
    #area = [(332,131),(27,688),(1137,701),(859,119)]

    
    # Iterate over the images in the folder
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        i = i+1
        if i > len(os.listdir(folder_path)):
            break
        frame = cv2.imread(file_path)  # Read the image
        height, width, channels = frame.shape[:3]
        '''
        # Create a folder to store the output images
        output_folder = os.path.join(folder_path, "output")
        create_folder(output_folder)
        '''
        # Create a folder to store the output labels
        #output = os.path.join(folder_path, "output_labels")
        #create_folder(output)
        
        
        # Perform inference and get the detections
        result_model = model(frame, agnostic_nms=True)[0]

        detections = sv.Detections.from_yolov8(result_model)
        label = []
        if len(detections)>0:
            
            for bbox, _, _, class_id, _ in detections:
                x1=int(bbox[0])
                y1=int(bbox[1])
                x2=int(bbox[2])
                y2=int(bbox[3])
                
                xn1 = np.round((x1+(x2-x1)/2)/width,6)
                yn1 = np.round((y1+(y2-y1)/2)/height,6)
                xn2 = np.round((x2-x1)/width,6)
                yn2 = np.round((y2-y1)/height,6)
                
                
                f = open(os.path.join(folder_path,filename[ :-3]+"txt"),'a')
                s = str(class_id)+' '+str(xn1)+' '+str(yn1)+' '+str(xn2)+' '+str(yn2)
                f.write(str(s)+"\n")
                    
            f.close()
        #cv2.imwrite(os.path.join(output_folder,filename),frame)
        #f.close()
        
        # Annotate boxes and labels for all classes
        
if __name__ == '__main__':
    main()

