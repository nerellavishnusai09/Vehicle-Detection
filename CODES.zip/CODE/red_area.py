import cv2
import numpy as np

def get_area_of_image(image_path, area):
  """
  Gets the area of an image as a new image using OpenCV.

  Args:
      image_path: Path to the image file.
      area: List of coordinates defining the cropping area. [(x1, y1), (x2, y2), ..., (xn, yn)]

  Returns:
      A NumPy array representing the cropped image area.
  """

  # Read the image
  image = cv2.imread(image_path)

  # Convert coordinates to integers
  area = np.int32(area)

  # Create a mask for the cropping area
  mask = np.zeros_like(image, dtype=np.uint8)
  cv2.fillConvexPoly(mask, area, (255, 255, 255))

  # Apply bitwise AND to get the cropped image
  cropped_image = cv2.bitwise_and(image, mask)

  return cropped_image

# Example usage
image_path = r"D:\Downloads\OPEN\vlcsnap-2024-04-07-09h34m09s576.png"  # Replace with your image path
area = [(0, 589), (5, 1060), (1900, 1070), (1910, 515), (1250, 95), (685, 85)]

cropped_image = get_area_of_image(image_path, area)

# You can now display or save the cropped image
cv2.imshow("Cropped Image", cropped_image)
cv2.waitKey(0)
cv2.destroyAllWindows()


