import os

def delete_duplicates(dir1, dir2):
    # Get list of files in both directories
    files_dir1 = set(os.listdir(dir1))
    files_dir2 = set(os.listdir(dir2))

    # Find common files
    common_files = files_dir1.intersection(files_dir2)

    # Delete common files from the second directory
    for file in common_files:
        os.remove(os.path.join(dir2, file))
        print(f"Deleted {file} from {dir2}.")

# Example usage
dir1 = r"D:\Downloads\oppo\Camera"
dir2 = r"D:\Downloads\oppo\WhatsApp Images"

delete_duplicates(dir1, dir2)
